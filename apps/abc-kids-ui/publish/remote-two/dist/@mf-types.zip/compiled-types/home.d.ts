export default function Home(): import("react/jsx-runtime").JSX.Element;
